from .src.package1.file1 import my_func
from .src.package2.file2 import my_other_func
from .src.file3 import my_other_other_func