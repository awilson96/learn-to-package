def my_func():
    print("Hello from file 1")
    


