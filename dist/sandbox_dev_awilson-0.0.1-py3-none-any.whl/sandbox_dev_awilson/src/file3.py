def my_other_other_func():
    print("Hello from file 3")
    
