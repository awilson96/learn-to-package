def my_other_func():
    print("Hello from file 2")
    