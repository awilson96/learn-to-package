from sandbox import my_func, my_other_func, my_other_other_func

my_func()
my_other_func()
my_other_other_func()