# Example Readme
This is my example Readme.

## Setup
To build a new sandbox ensure that you have met the following requirements:
1. Place your project <my_project_name> in another folder named <my_project_name>_build so that your folder tree looks like this: 
my_project_name_build
|__
   my_project_name
   |__
      src/
      |__
         file1.py
         file2.py
         __init__.py
      test/
      |__
         __init__.py
         my_test1.py
         my_test2.py
      __init__.py
    
    

    

## Test Cases